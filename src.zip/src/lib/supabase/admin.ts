// src/lib/supabase/admin.ts  ← NUNCA expor ao browser
import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/types/database.types'

export function createAdminClient() {
  return createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,  // chave secreta
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  )
}